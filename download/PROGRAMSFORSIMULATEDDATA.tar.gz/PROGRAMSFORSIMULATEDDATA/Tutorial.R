library(hypred)
library(rrBLUP)
library(glmnet)

### To be replaced by the location of your current directory
currentDirectory<-"~/Bureau/PROGRAMSFORSIMULATEDDATA"

setwd(currentDirectory)
source("getAccuracy.R")
source("getAccuracyRegeneratedTest.R")
source("functionsForAccuracy.R")
source("getAccuracyMeanDesign.R")

####INPUT

# nbSNPS : number of SNPS
# chroLength : length of the chromosome in Morgan
# nbQTLs : number of QTLs
# QTLlocations : vector containing location of the QTLs, they have to be on markers
# QTLeffects : vector containing QTL effects
# heritability : heritability of the considered Trait
# n : number of individuals present in the TRN and that are not full sibs
# nbFullSibs : number of Full Sibs that will be considered in the TRN set
# nbTest : number of Test individuals
# nbgeneration : number of generation during which the  population will evolve by random mating
# REML : Boolean, TRUE if we want to compute the tuning parameter by REML 
# vs FALSE if we want a tuning parameter heritability based
# REMOVEQTL : Boolean, TRUE if we want to remove the QTL from the design matrix
# vs FALSE if we do not want to remove QTLs

### Example of parameter values
nbSNPS<-100
chroLength<-1
nbQTLs<-2
QTLlocations<-c(0.03,0.80)
QTLeffects<-c(1,-2)
heritability<-0.4
n<-400
nbFullSibs<-100
nbTest<-100
nbgeneration<-50
REML=TRUE
REMOVEQTL=FALSE
set.seed(288)

####To begin with, compute the accuracycorresponding to one given TRN design 
Result<-getAccuracy(REML, REMOVEQTL, nbSNPS, chroLength, nbQTLs, QTLlocations, QTLeffects, heritability, n, nbFullSibs, nbTest, nbgeneration) 

### It gives the following informations

### Theoretical Accuracy according to our formula
Result$TheoreticalAccuracy
          [,1]
[1,] 0.6407343

### Empirical Accuracy 
Result$EmpiricalAccuracy
         [,1]
[1,] 0.624743

### Theoretical Bias
Result$TheoreticalBias
[1] 4.663804e-17

### Empirical Bias
Result$EmpiricalBias
[1] -1.065435e-16

### TheoreticalQuadraticError
Result$TheoreticalQuadraticError
[1] 1.197594

### Empirical QuadraticError
Result$EmpiricalQuadraticError
[1] 1.13913

## Corrected LD between QTL and markers for the TRN set
Result$LDCorrectedWithQTLTRN
                [,1]          [,2]
  [1,]  6.043782e-04 -3.246833e-03
  [2,]  6.669885e-04 -2.903722e-03
  [3,]  6.669885e-04 -2.903722e-03
  [4,]  1.130387e-03 -1.978427e-03
  [5,]  3.578396e-03 -3.507996e-05
  [6,]  2.486811e-03 -9.080598e-04
  [7,]  4.116045e-04 -1.257747e-03
  [8,] -8.107171e-04 -1.586352e-03
  [9,] -1.096940e-02 -9.048107e-05
 [10,] -1.163776e-02 -1.597354e-03
......


### Our New Proxy
Result$NewProxy
[1] 0.5864267

### Proxy based on Me1 (Ne based on Hill and Weirr)
Result$proxyMe1
[1] 0.616946

### Proxy based on Me2 (Ne based on Hill and Weirr)
Result$proxyMe2
[1] 0.6146436

### Proxy based on Me3 (Ne based on Hill and Weirr)
Result$proxyMe3
[1] 0.6115382

### Proxy based on Li and Ji
Result$ProxyLiJi
[1] 0.5209323

### Me corresponding to our New Proxy
$NewMe
[1] 54.38046

### Me1 (Ne based on Hill and Weirr)
Result$Me1
[1] 16.97016

### Me2 (Ne based on Hill and Weirr)
Result$Me2
[1] 19.59948

### Me3 (Ne based on Hill and Weirr)
Result$Me3
[1] 23.19293

### MeLiJi 
Result$MeLiJi
[1] 158


############################### If now we are willing to regenerate Test individuals, keeping the same TRN design matrix
############################### Last argument is the number of regenerated Test samples 

#nbSim is the number of samples 
nbSim<-2
## Run the function getAccuracyWithRegeneratedTest
TAB<-getAccuracyWithRegeneratedTest(REML, REMOVEQTL, nbSNPS, chroLength, nbQTLs, QTLlocations, QTLeffects, heritability, n, nbFullSibs, nbTest, nbgeneration,nbSim) 

## The result is a Table where each rows refers to one Test set
TAB
 IDsim TheoreticalAccuracy EmpiricalAccuracy TheoreticalBias EmpiricalBias TheoreticalQuadraticError EmpiricalQuadraticError  NewProxy  proxyMe1  proxyMe2
1     1           0.6940620          0.671848    3.311126e-16 -5.058844e-16                  1.176417                1.263527 0.5856227 0.6264969 0.6253869
2     2           0.6988775          0.710846    8.785075e-16 -1.136788e-16                  1.178024                1.173824 0.5873441 0.6264863 0.6253752
 proxyMe3 ProxyLiJi    NewMe      Me1      Me2      Me3 MeLiJi
1 0.6237687 0.5414737 77.62414 8.919160 10.60885 13.08838    170
2 0.6237556 0.5414737 74.43839 8.935196 10.62685 13.10863    170

### If we want to compute the average
myMeans<-colMeans(TAB1, na.rm = TRUE, dims = 1)
      IDsim       TheoreticalAccuracy         EmpiricalAccuracy           TheoreticalBias             EmpiricalBias TheoreticalQuadraticError 
             1.050000e+01              6.187076e-01              6.017630e-01              2.950582e-17              1.444163e-16              1.328870e+00 
  EmpiricalQuadraticError                  NewProxy                  proxyMe1                  proxyMe2                  proxyMe3                 ProxyLiJi 
             1.363019e+00              5.946145e-01              6.156507e-01              6.132206e-01              6.099688e-01              5.842698e-01 
                    NewMe                       Me1                       Me2                       Me3                    MeLiJi 
             4.378441e+01              1.844576e+01              2.123929e+01              2.502997e+01              5.725000e+01 


#########
#### If we are willing to to take the average on TRN design matrices, i.e. Random Design


#nbSim is the number of samples 
nbSim<-3
## Run the function getAccuracyMeanDesign, that allows to compute nbsim accuracy, each one with its own Training Design matrix
TABMeanDesign<-getAccuracyMeanDesign(REML, REMOVEQTL, nbSNPS, chroLength, nbQTLs, QTLlocations, QTLeffects, heritability, n, nbFullSibs, nbTest, nbgeneration,nbSim) 

TABMeanDesign
  IDsim TheoreticalAccuracy EmpiricalAccuracy TheoreticalBias EmpiricalBias TheoreticalQuadraticError EmpiricalQuadraticError  NewProxy  proxyMe1  proxyMe2  proxyMe3 ProxyLiJi
1     1           0.6206426         0.6025473    3.275354e-16 -1.015171e-15                  1.212380                1.225374 0.5868822 0.6180073 0.6158116 0.6128286 0.5091515
2     2           0.6844608         0.6554044   -4.385274e-17 -4.096468e-16                  1.180324                1.666594 0.5879015 0.6168972 0.6145900 0.6114791 0.5066946
3     3           0.6808493         0.7196206   -2.342585e-16  7.071947e-16                  1.202251                1.148409 0.5881238 0.6166426 0.6143101 0.6111701 0.4981355
     NewMe      Me1      Me2      Me3 MeLiJi
1 53.77882 15.76800 18.26196 21.69304    181
2 52.43766 17.02550 19.66101 23.26190    186
3 52.14605 17.31491 19.98278 23.62251    204






