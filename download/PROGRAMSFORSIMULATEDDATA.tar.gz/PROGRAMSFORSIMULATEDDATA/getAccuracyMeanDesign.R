

getAccuracyMeanDesign <-
function (REML=FALSE, REMOVEQTL=FALSE, nbSNPS, chroLength, nbQTLs, QTLlocations, QTLeffects, heritability, n, nbFullSibs, nbTest, nbgeneration,nbSim) {

### function that allows to compute the accuracy for nbSim samples,
#each sample has its own Training Design matrix 
## it computes the accuracy for each of the Training Design matrices

#INPUT

# REML : Boolean, TRUE if we want to compute the tuning parameter by REML 
# vs FALSE if we want a tuning parameter heritability based
# REMOVEQTL : Boolean, TRUE if we want to remove the QTL from the design matrix
# vs FALSE if we do not want to remove QTLs
# nbSNPS : number of SNPS
# chroLength : length of the chromosome in Morgan
# nbQTLs : number of QTLs
# QTLlocations : vector containing location of the QTLs, they have to be on markers
# QTLeffects : vector containing QTL effects
# heritability : heritability of the considered Trait
# n : number of individuals present in the TRN and that are not full sibs
# nbFullSibs : number of Full Sibs that will be considered in the TRN set
# nbTest : number of Test individuals
# nbgeneration : number of generation during which the  population will evolve by random mating
# nbSim : number of Traing  Design matrices

#OUTPUT

# List containing in the following order
# TheoreticalAccuracy : Theoretical Accuracy according to our formula
# EmpiricalAccuracy : Empirical accuracy
# EmpiricalBias : Empirical bias
# TheoreticalQuadraticError : Theoretical Quadratic Error
# EmpiricalQuadraticError : Empirical Quadratic Error 
# LDCorrectedWithQTLTRN : Corrected LD between markers and QTLs, for the Training
# NewProxy : Our New Proxy
# proxyMe1 : Proxy based on Me1 (Ne based on Hill and Weirr)
# proxyMe2 : Proxy based on Me2 (Ne based on Hill and Weirr)
# proxyMe3 : Proxy based on Me3 (Ne based on Hill and Weirr)
# ProxyLiJi : Li and Ji's Proxy
# NewMe : Me corresponding to our method
# Me1 : Me1 (Ne based on Hill and Weirr)
# Me2 : Me2 (Ne based on Hill and Weirr)
# Me3 :  Me2 (Ne based on Hill and Weirr)
# MeLiJi : MeLiJi corresponding to Li and Ji


summaryTable = data.frame(IDsim=1:nbSim, TheoreticalAccuracy=rep(0,nbSim), EmpiricalAccuracy=rep(0,nbSim), TheoreticalBias=rep(0,nbSim),
EmpiricalBias=rep(0,nbSim), TheoreticalQuadraticError=rep(0,nbSim), EmpiricalQuadraticError=rep(0,nbSim), 
NewProxy=rep(0,nbSim), proxyMe1=rep(0,nbSim), proxyMe2=rep(0,nbSim), 
proxyMe3=rep(0,nbSim), ProxyLiJi=rep(0,nbSim), NewMe=rep(0,nbSim),
 Me1=rep(0,nbSim), Me2=rep(0,nbSim), Me3=rep(0,nbSim), MeLiJi=rep(0,nbSim))


for (idSample in 1:nbSim) {

Result<-getAccuracy(REML, REMOVEQTL, nbSNPS, chroLength, nbQTLs, QTLlocations, QTLeffects, heritability, n, nbFullSibs, nbTest, nbgeneration)

summaryTable[idSample,2:17]<-Result[-7]

}


return(summaryTable)

}



