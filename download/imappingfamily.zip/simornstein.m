function [X]=simornstein(pas,sizechro)

%cette fonction simule un processus d orstein Uhlenbeck X
%elle retourne la valeur absolue Z du processus d OU

%pas designe le pas de discretisation en M

%sizechro designe la taille du chromosome en M


vect=[0:pas:sizechro];

N=size(vect,2);

X=zeros(N,1);
Z=zeros(N,1);

X(1)=randn;
Z(1)=abs(X(1));

for i=1:N-1

epsilon= sqrt(1-exp(-4*pas))*randn;
X(i+1)=exp(-2*pas)*X(i)+ epsilon;

end




%plot(vect,X)
