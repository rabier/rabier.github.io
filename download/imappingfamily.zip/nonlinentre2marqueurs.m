function X=nonlinentre2marqueurs(dmark,pas,a,b,rho)

%cette fonction renvoie le processus interpole entre 2 marqueurs X
%!!!!!c est l interpolation non lineaire de linterval Mapping


%a est la valeur de la stat de test au premier marqueur
%b est la valeur de la stat de test au deuxieme marqueur

t=[0:pas:dmark];

nbtest=size(t,2); 


%on remplit ce vecteur
%attention on travaille en morgans 


X=zeros(nbtest,1);
X(1)=a;
X(nbtest)=b;


for i=1:nbtest-2
    
    t=pas*i;
    alpha=Q(t,1,1,0,dmark)+Q(t,1,-1,0,dmark)-1;
    beta=Q(t,1,1,0,dmark)-Q(t,1,-1,0,dmark);
    
    esp_2pjmoin1carre=2*(  Q(t,1,1,0,dmark)^2*(1-haldane(dmark)) +  Q(t,1,-1,0,dmark)^2*haldane(dmark) +   Q(t,-1,1,0,dmark)^2*haldane(dmark) + Q(t,-1,-1,0,dmark)^2*(1-haldane(dmark)) ) - 1;
    
    X(i+1)=(alpha*a+beta*b)/sqrt(esp_2pjmoin1carre);
    
end

