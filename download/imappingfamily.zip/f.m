function resultat = f(valeursurmark)

%f(vectdmark,pas,valeursurmark,matcovsurmarqueurs,s)
%matcovsurmarqueurs est la matrice de covariance sur les marqueurs
global vectdmark
global pas
global matcov
global seuil


t=[0:pas:sum(vectdmark)];

nbtest=size(t,2);

X=zeros(nbtest,1);


%on cherche desormais les indices des marqueurs
%on les mettra ds un vecteur colonne indmark
indmark=zeros(size(vectdmark,1)+1,1);

%indmark(i) designe lindice du marqueur i
indmark(1)=1;
d=0;
for i=1:size(vectdmark,1)
    d=d+vectdmark(i);
    indmark(i+1)=(d/pas) + 1;
end
    
X(indmark)=valeursurmark;
%je calcule ce qui se passe entre les marqueurs
for i=1:size(vectdmark,1)
X(indmark(i):indmark(i+1))=nonlinentre2marqueurs(vectdmark(i),pas,X(indmark(i)),X(indmark(i+1)),matcov(i,i+1));
end
%au passage jai recalcule ce qui ct passe au marqueur
%car ma fonction nonlinentre2marqueurs calcule aussi sur les marqueurs




%je regarde desormais quand on est ce que l on sort de la boule!!
%sije sors de la boule ma fonction vaut 0
%sinon c un
for i=1:size(vectdmark,1)
for j=indmark(i)+1:indmark(i+1)-1
    if (abs(X(j))>seuil)
        resultat=0;
        return
    else
        resultat=1;
    end 
end
end


        
