function seuil=dmcbetweenmarkers(vectdmark,pas,nbpere,quantile,nbtraj)

%cette fonction calcule le seuil pour l interval mapping
%par linterpolation non lineaire qu est linterval mapping

%cest lanalogue de interpnonlinintervalmapping mais on peut choisir le
%nbpere ici

%vectdmark designe un vecteur colonne avec toutes les distances entre les
%marqueurs en cm
%pas le pas de discretisation du processus en cM
%c a dire tous les combien on teste 


h = waitbar(0,'please wait','CreateCancelBtn','setappdata(gcbf,''canceling'',1)');
setappdata(h,'canceling',0)

%on cherche desormais les indices des marqueurs
%on les mettra ds un vecteur colonne indmark
indmark=zeros(size(vectdmark,1)+1,1);

%indmark(i) designe lindice du marqueur i
indmark(1)=1;
d=0;
for i=1:size(vectdmark,1)
    d=d+vectdmark(i);
    indmark(i+1)=(d/pas) + 1;
end
    


t=[0:pas:sum(vectdmark)];
nbtest=size(t,2);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%on calcule la matrice de covariance des tests que sur les marqueurs
matcovfinal=matcovsurmarqueurs(vectdmark);



%nbtraj=1000000;
%quantile=0.95;
sup=zeros(1,nbtraj);
suptrie=zeros(1,nbtraj);
ind=nbtraj*quantile;


for traj=1:nbtraj

waitbar(traj/nbtraj)
if getappdata(h,'canceling')
              seuil=0;
            break
            end

X=zeros(nbtest,nbpere);   
%attention ds simornstein on est en cM

    for nbp=1:nbpere

        [Y]=simornstein(pas/100,sum(vectdmark)/100);

           %[Y]=P*sqrt(DD)*P'*randn(size(matcovfinal,1),1);
    
            for i=1:size(vectdmark,1)
            X(indmark(i):indmark(i+1),nbp)=nonlinentre2marqueurs(vectdmark(i),pas,Y(indmark(i)),Y(indmark(i+1)),matcovfinal(i,i+1));
            end    
    
    
    end    
    
sup(traj)=max(sum(X.^2,2));
end


suptrie=sort(sup);

seuil=suptrie(ind);
 
delete(h)
