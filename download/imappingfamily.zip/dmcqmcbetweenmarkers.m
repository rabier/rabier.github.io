function  [u,pourcentage]=dmcqmcbetweenmarkers(vectdmark,pas,quantile)
%


% cette fonction calcule le quantile  du sup du xi2 d'O.U
%Le nombre de degr�s de libert� est 1 car allan genz ne sait pas faire mieux
%pour linstant

% cest du dmcqmc et on teste entre les marqueurs
%il y a au moins un test dans chaque marker interval

%pourcentage est le pourcentage auquel le quantile u trouv� correspond 
%evidemment c est tres proche du souhaite


%version web

h = waitbar(0,'please wait','CreateCancelBtn','setappdata(gcbf,''canceling'',1)');
setappdata(h,'canceling',0)

%on va considerer que la distance entre les marqueurs peut �tre variable.
%vectdmark est un vecteur colonne designant la distance entre les diff�rents marqueurs en cM
%ainsi vectdmark(1) est la distance entre les 2 premiers marqueurs
%vectdmark(i) est la distance entre le ieme marqueur et le i+1 �me marqueur

%pas le pas de discretisation du processus en cM
%c a dire tous les combien on teste 

%on supposera qu lon aura tjs au moins un test entre 2 marqueurs
%consecutifs



matcov=matcovsurmarqueurs(vectdmark);
%matcov est la matrice de cov sur les marqueurs

% on cherche l a priori de depart
%pour faire debuter notre algo de newton

erreur=zeros(100,1);

for compteur=1:100
    
waitbar(compteur/2100)
x0=compteur/10;
a=-x0*ones(1,size(matcov,1));
b=x0*ones(1,size(matcov,1));

[ p, e ] = qsimvnv( 3000, matcov, a, b );

erreur(compteur)=abs(p-quantile);


if getappdata(h,'canceling')
 u=0;
 pourcentage=0;
 delete(h)
return
end

end

[valeur,endroit]=min(erreur);

x0=endroit/10;



a=-x0*ones(1,size(matcov,1))
b=x0*ones(1,size(matcov,1));

[p e ef efe] =qsimvnefweb(5000,matcov,a,b,'f',vectdmark,pas,x0);
%a noter que p cest comme qsimvn
fx0=ef*p-quantile;

%calcule de fprimex0 pour linitialisation

x1=x0;
     for i=1:20
            waitbar((i+1)/21)
   
            
            if getappdata(h,'canceling')
              u=0;
              pourcentage=0;
              delete(h)
            return
            end
    
            if (abs(fx0)<0.001)
                fx0;
                u=x1^2;
                break
            end

            
            %jecalcule la derivee
            abis=(-abs(x0)-0.1)*ones(1,size(matcov,1));
            bbis=(abs(x0)+0.1)*ones(1,size(matcov,1));

            
            
            [pbis ebis efbis efebis] =qsimvnefweb(5000,matcov,abis,bbis,'f',vectdmark,pas,abs(x0)+0.1);
            fx0bis=efbis*pbis-quantile;
            fprimex0=(fx0bis-fx0)/0.1;
            
        
            
            
            %maintenant que jai la derivee je peux faire du newton
                    
            x1=x0-fx0/fprimex0;
            
            [p e ef efe]=qsimvnefweb(5000,matcov,-abs(x1)*ones(size(matcov,1),1),abs(x1)*ones(size(matcov,1),1),'f',vectdmark,pas,abs(x1));
            fx1=ef*p-quantile;
            
            %je remets a jour
            x0=x1;
            fx0=fx1;
            u=x1^2;   
            
     end

pourcentage=fx0+quantile;
%u=a(1)^2;


delete(h)