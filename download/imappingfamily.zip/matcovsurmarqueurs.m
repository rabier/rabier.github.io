function [matcovfinal]=matcovsurmarqueurs(vectdmark)

%cette fonction calcule la matrice de covariance lorsque l'on teste
%uniquement sur les marqueurs


%on va considerer que la distance entre les marqueurs peut �tre variable.
%vectdmark est un vecteur colonne designant la distance entre les diff�rents marqueurs en cM
%ainsi vectdmark(1) est la distance entre les 2 premiers marqueurs
%vectdmark(i) est la distance entre le ieme marqueur et le i+1 �me marqueur



%matcov sera la matrice de covariance mais seulement triangulaire
%sup�rieure
matcov=zeros(size(vectdmark,1)+1);

%on remplit deja matcov pour les intervalles definis par 2marqueurs
%et les esperances
for i=1:size(vectdmark,1)
  
  for j=i+1:size(vectdmark,1)+1  

      matcov(i,j)=exp(-2*sum(vectdmark(i:j-1))/100);
      
    
  end
  
end


matcovfinal=zeros(size(vectdmark,1)+1);
matcovfinal=matcov+matcov'+eye(size(vectdmark,1)+1);