function resultat = frebai(valeursurmark)

%f(vectdmark,pas,valeursurmark,matcovsurmarqueurs,s)
%matcovsurmarqueurs est la matrice de covariance sur les marqueurs
global vectdmark
global matcov
global seuil

resultat=1;
%xi sera un vecteur contenant toutes les statistiques entre les marqueurs,
%cadire autant que dintervalles car je fais juste un test entre les
%marqueurs
xi=zeros(size(vectdmark,1),1);
%attention les xi sont des stats au carre
    
X=valeursurmark;
%X vecteur avec ttes les stats au marqueur (pas au carre)

for i=1:size(vectdmark,1)
num=X(i)^2 + X(i+1)^2 -2*matcov(i,i+1)*X(i)*X(i+1);
denom=(1+matcov(i,i+1))*(1-matcov(i,i+1));
xi(i)=num/denom;

end

ratio=zeros(size(vectdmark,1),1);

for i=1:size(vectdmark,1)
ratio(i)=X(i+1)/X(i);
end




for i=1:size(vectdmark,1)
    if ratio(i)>matcov(i,i+1) & ratio(i)*matcov(i,i+1)<1 & xi(i)>seuil^2
        resultat=0;
        return
    end 
end
        
        
