function [X]=simornsteinvect(vectdmark)

%cette fonction simule un processus d orstein Uhlenbeck X
%discret 
%la discretisation correspond a des tests que sur les marqueurs
%vectdmark est le vecteur colonne des distances entre marqueurs en M



N=size(vectdmark,1)+1;

X=zeros(N,1);
Z=zeros(N,1);

X(1)=randn;
Z(1)=abs(X(1));

for i=1:size(vectdmark,1)

epsilon= sqrt(1-exp(-4*vectdmark(i)))*randn;
X(i+1)=exp(-2*vectdmark(i))*X(i)+ epsilon;

end




%plot(vect,X)
