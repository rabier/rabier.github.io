function recomb=haldane(distance)

%cette fonction calcule etant donne une distance en centi morgan
% entre 2 marqueurs
%le taux de recombinaison suivant la formule de Haldane


recomb=(1-exp(-2*distance/100))/2;

