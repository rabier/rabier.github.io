function [matcov,esp_pj,esp_2pjmoin1carre]=triangsup2markweb(dmark,pas)

%cette fonction renvoie 
%la matrice de covariance triangulaire superieure

%on ne traite pas la continuite (bien!!)
%version web

%Contexte: on a 2 marqueurs et que lon test entre ces 2 marqueurs
%dmark designe la distance entre les deux marqueurs en cM
%pas le pas de discretisation du processus en cM
%c a dire tous les combien on teste 



t=[0:pas:dmark];

nbtest=size(t,2); 

esp_pj=zeros(nbtest,1);
%esp_pj est un vecteur contenant toutes les esperances des pj(t)

esp_2pjmoin1carre=zeros(nbtest,1);
%esp_2pjmoin1carre est un vecteur contenant toutes les esperance des
%(2pj-1)^{2}(t)




esp_pj(1)=0.5;
esp_pj(nbtest)=0.5;

esp_2pjmoin1carre(1)=1;
esp_2pjmoin1carre(nbtest)=1;



tl=0;
tr=dmark;

fin=dmark-pas;
d=tr-tl;



for i=1:nbtest-2

t=i*pas;

esp_pj(i+1)=0.5;


esp_2pjmoin1carre(i+1)=2*(  Q(t,1,1,tl,tr)^2*(1-haldane(d)) +  Q(t,1,-1,tl,tr)^2*haldane(d) +   Q(t,-1,1,tl,tr)^2*haldane(d) + Q(t,-1,-1,tl,tr)^2*(1-haldane(d)) ) - 1;



end



matcov=eye(nbtest);
%matcov designe la matrice de covariance du processus
%donc sur la diagonale j ai que des 1

%je ne remplis pas la premiere ligne et la derniere colonne
%car il y aura des pb avec tl et tr
%qui sont les memes ds ce cas la

for k=2:nbtest-2

   for m=k+1:nbtest-1

t=(k-1)*pas;
tplusd=(m-1)*pas;

esp_ttplusd=0.5*( Q(t,1,1,tl,tr)* Q(tplusd,1,1,tl,tr)*(1-haldane(d)) +  Q(t,1,-1,tl,tr)* Q(tplusd,1,-1,tl,tr)*haldane(d) +   Q(t,-1,1,tl,tr)* Q(tplusd,-1,1,tl,tr)*haldane(d) + Q(t,-1,-1,tl,tr)* Q(tplusd,-1,-1,tl,tr)*(1-haldane(d)) );


matcov(k,m)=( 4*esp_ttplusd-1 )/(sqrt(esp_2pjmoin1carre(k))*sqrt(esp_2pjmoin1carre(m)));


end

end





%%Replissons now la premiere ligne



%tout dabord on ne traite pas la derniere colonne
for m=2:nbtest-1

tplusd=(m-1)*pas;
num=2*(Q(tplusd,1,1,tl,tr)*(1-haldane(d)) + Q(tplusd,1,-1,tl,tr)*haldane(d))-1  ;
matcov(1,m)=num/sqrt(esp_2pjmoin1carre(m));

end
 
  
%now la derniere colonne et premiere ligne
matcov(1,nbtest)=2*(1-haldane(d))-1;


%now tte la derniere colonne


for m=2:nbtest-1

tplusd=(m-1)*pas;

num=2*(Q(tplusd,1,1,tl,tr)*(1-haldane(d)) + Q(tplusd,-1,1,tl,tr)*haldane(d))-1  ;

matcov(m,nbtest)=num/sqrt(esp_2pjmoin1carre(m));


end
