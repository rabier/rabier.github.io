function seuil=dmconmarkers(vectdmark,nbpere,quantile,nbtraj)

%cette fonction calcule le seuil pour l interval mapping
%on test sur les marqueurs

%cest lanalogue de interpnonlinintervalmapping mais on peut choisir le
%nbpere ici


%vectdmark designe un vecteur colonne avec toutes les distances entre les
%marqueurs en cm
%pas le pas de discretisation du processus en cM
%c a dire tous les combien on teste 

h = waitbar(0,'please wait','CreateCancelBtn','setappdata(gcbf,''canceling'',1)');
setappdata(h,'canceling',0)



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%on calcule la matrice de covariance des tests que sur les marqueurs
matcovfinal=matcovsurmarqueurs(vectdmark);

nbtest=size(vectdmark,1)+1;

%nbtraj=1000000;
%quantile=0.95;
sup=zeros(1,nbtraj);
suptrie=zeros(1,nbtraj);
ind=nbtraj*quantile;


for traj=1:nbtraj

waitbar(traj/nbtraj)
if getappdata(h,'canceling')
            seuil=0;
            delete(h)
            return
end

    Y=zeros(nbtest,nbpere);   
%attention ds simornstein on est en cM

    for nbp=1:nbpere

        Y(:,nbp)=simornsteinvect(vectdmark/100); 
    
    
    end    
    
sup(traj)=max(sum(Y.^2,2));
end


suptrie=sort(sup);

seuil=suptrie(ind);
 
delete(h)
