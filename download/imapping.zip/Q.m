function resultat=Q(t,i,j,tl,tr)


Vector=[i j];

%cette fonction calcule le Qt^{i,j}



if Vector==[1 1]

resultat=(1-haldane(t-tl))*(1-haldane(tr-t))/(1-haldane(tr-tl));

else if Vector==[1 -1]

resultat=(1-haldane(t-tl))*haldane(tr-t)/haldane(tr-tl);

else if Vector==[-1 1]

resultat=haldane(t-tl)*(1-haldane(tr-t))/haldane(tr-tl);

else 

resultat=haldane(t-tl)*haldane(tr-t)/(1-haldane(tr-tl));


end;

end;

end;
