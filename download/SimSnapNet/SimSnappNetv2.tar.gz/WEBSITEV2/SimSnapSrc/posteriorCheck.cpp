/*
 *  posteriorCheck.cpp
 *  
 *
 *  Created by David Bryant on 22/06/10.
 *  Copyright 2010 University of Auckland. All rights reserved.
 *
 */

#include "posteriorCheck.h"

