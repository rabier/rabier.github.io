#We give here two  examples on how to run SPIMAP

#FIRST EXAMPLE : ONE WGD LOCATED IN THE SPECIES TREE
#SECOND EXAMPLE : TWO  WGDs LOCATED IN THE SPECIES TREE

#in the folder "dnawith1WGD" (resp. "dnawith2WGD"), you will find 20 data sets generated with the species tree with one WGD (resp. two WGDs)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#FIRST EXAMPLE : ONE WGD LOCATED IN THE SPECIES TREE

#we consider a species tree with 4 taxon (A, B, C, D)

#on this example, the WGD is located just before the speciation A|B in the middle of the branch
#We consider a probability of loss of 0.1 at the WGD (specified in the input file
#speciestreewith1WGD.stree)


#note that on this example, we consider as data set the file dnawith1WGD/5/5.nt.align but  other dna alignments are located in
#the folder dnawith1WGD. All the alignments were generated using the same species tree with 1 WGD.


#Input files required to run SPIMAP on this example :

speciestreewith1WGD.stree : species tree
5.nt.align : sequence alignments (FASTA format)
ABCD.smap : gene to species map
ABCD.params : substitution rate parameter file

#The following command 

bin/spimap -s speciestreewith1WGD.stree -S ABCD.smap -a dnawith1WGD/5/5.nt.align -o example1 -i 100 -D 0.02 -L 0.03 -g 2 -V 1 -p ABCD.params --log resultsexample1 --informationduploss -r --treeSampled -LR 0.95

#note that we consider only 100 iterations for this tutorial 

#will produce the following output 

Species tree from input file, including WGD nodes
     /-- A 
  /+++     
/-+  \-- B 
| |        
+ \--- C   
|          
\---- D    

#each cross refers to one node                      
#although the user has to add only one node to specify a WGD (in the species tree file),
#  the sofwtare  adds another supplementary node in order to model what happens exactly at the WGD event
#The two nodes which surround the WGD event are called WGD_before and WGD_at  
#be careful, in the paper the node WGD_at is called WGD_after

           
(
  (
    (
      (
        (
          A:7.060000,
          B:7.060000
        ):2.500000
      )WGD_at:0.000000
    )WGD_before:2.500000,
    C:12.060000
  ):5.970000,
  D:18.030001
);


# The software describes all the WGD and their parameters
#on this example we only have one WGD in our species tree
#the branch where the WGD is located, is splitted in three parts
#BEFORE, AT, AFTER
#'total distance' gives the length of the branch on which the WGD is placed
#'percent distance' indicates where the WGD is located on that branch,
#as a percentage of the total distance starting from the parent node 
#distances 'before/after' are the distances before/after the WGD 


#note that the WGD event number is 0 on this example.
#Since we only have one WGD in our species tree, the WGD event number
#is not useful here. However, when there are several WGDs in the species tree, the WGD event number
# is useful in order to interpret the reconciliation

WGD parameters, if any:
WGD event number0:
        loss probability:  0.100000
        percent distance:  0.500000
        total distance:    5.000000
        node number at the end of 'before' period: 8
        distance 'before': 2.500000
        node number at the end of 'at' period:     7
        node number at the end of 'after' period:  5
        distance 'after':  2.500000


#Then, it prints the WGD species tree , the number corresponding to each node
# his name and its children
# for instance node 4 has two children : 
#node 8 which is WGD_before  and node 3 which is  species C

the WGD species tree
0	D
1	A
2	B
3	C
4	
	8	WGD_before
	3	C
5	
	1	A
	2	B
6	
	4	
	0	D
7	WGD_at
	5	
8	WGD_before
	7	WGD_at


#note that  names of  node 4 5 6 will be given later


the WGD species tree graphically:
(
  (
    (
      (
        (
          A:7.060000,
          B:7.060000
        ):2.500000
      )WGD_at:0.000000
    )WGD_before:2.500000,
    C:12.060000
  ):5.970000,
  D:18.030001
);



     /-- A 
  /+++     
/-+  \-- B 
| |        
+ \--- C   
|          
\---- D    
           
#then, it prints the species tree without WGD  (i.e. reduced species tree)          
           
Reduced species tree:
(
  (
    (
      A:7.060000,
      B:7.060000
    ):5.000000,
    C:12.060000
  ):5.970000,
  D:18.030001
);


   /-- A 
  /+     
/-+\-- B 
| |      
+ \--- C 
|        
\---- D  
     

#From the sequence alignments , we get the  'Neighbor-joining' tree


Initial gene tree from Neighbor-joining:
   /- B_12  
  /+        
  |\- A_11  
 /+         
 ||/- B_15  
 |\+        
/+ \- A_14  
||          
||/- D_39   
|\+         
| \- D_38   
|           
+   /- A_26 
|  /+       
| /+\- B_24 
| ||        
|/+\- B_27  
|||         
\+\- C_36   
 |          
 |/- A_34   
 \+         
  \- A_31   
            

#at the end, it prints the species tree and the final gene tree  

now printing species tree
     /-- A 
  /+++     
/-+  \-- B 
| |        
+ \--- C   
|          
\---- D   



now printing final gene tree
    
    /-------- B_12  
   /+               
   |\--- A_11       
 /-+                
 | |/---- B_15      
 | \+               
/+  \---- A_14      
||                  
||         /- D_39  
|\---------+        
|          \- D_38  
|                   
+   /-- A_26        
|  /+               
| /+\--- B_27       
| ||                
|/+\- B_24          
|||                 
|||/---------- A_34 
\+\+                
 | \---- A_31       
 |                  
 \----- C_36      

     

#it also gives the gene tree with 
# the number corresponding to each node
# its name and its children
#for instance node number 12 is called n6
#and has two children : node number 10 called D_38, and node number 11 called D_39
#it will be useful for the reconciliation


0	A_11
1	B_12
2	A_14
3	B_15
4	B_24
5	A_26
6	B_27
7	A_31
8	A_34
9	C_36
10	D_38
11	D_39
12	n6
	11	D_39
	10	D_38
13	n5
	3	B_15
	2	A_14
14	n4
	1	B_12
	0	A_11
15	n10
	5	A_26
	6	B_27
16	n11
	8	A_34
	7	A_31
17	n3
	14	n4
	13	n5
18	n9
	15	n10
	4	B_24
19	n7
	21	n8
	9	C_36
20	n2
	17	n3
	12	n6
21	n8
	18	n9
	16	n11
22	n1
	20	n2
	19	n7


#in the same way, it recalls  the different nodes corresponding to 
#the species tree

0	D
1	A
2	B
3	C
4	n2
	8	WGD_before
	3	C
5	n5
	1	A
	2	B
6	n1
	4	n2
	0	D
7	WGD_at
	5	n5
8	WGD_before
	7	WGD_at
          


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#In the file example1.recon you will find the RECONCILIATION
#it now specifies which nodes are reconciled at the WGD

#As in the original version of SPIMAP : 
#first column refers to the gene tree :  name of the node
#second column refers to the species tree : name of the node
#third column indicates the evolutionary event : 'gene', 'speciation', 'duplication', 'WGD'
#note that when the evolutionary event is a WGD , column 2 also gives  the number associated to this WGD
#it is useful when the species tree has more than one WGD (cf. our next example
#with 2 WGDs located in the species tree)
 

more example1.recon 

A_11	A	gene
B_12	B	gene
A_14	A	gene
B_15	B	gene
B_24	B	gene
A_26	A	gene
B_27	B	gene
A_31	A	gene
A_34	A	gene
C_36	C	gene
D_38	D	gene
D_39	D	gene
n6	D	dup
n5	n5	spec
n4	n5	spec
n10	n5	spec
n11	A	dup
n3	WGD_at0	WGD
n9	n5	dup
n7	n2	spec
n2	n1	spec
n8	WGD_at0	WGD
n1	n1	dup


#we can see that the software finds two duplications at the WGD 
#indeed, the nodes n3 and n8 both map to the WGD
#note also that the WGD event number is 0 since there is only one WGD in our species tree

# the file example1.duplosslasttree gives the number of events 

more example1.duplosslasttree 
4,0,6,2
#a total of 4 losses, 0 loss at the WGD, a total of 6 duplications, 2 duplications at the WGD
#be careful we only consider 100 iterations on this example
# as a result, you will probably find a different result if you run it with a large
#number of iterations

# if we want to see how has evolved the number of events (ie the number of events
#corresponding to  some tree sampled) 
more example1.duploss 



#To obtain the completeloglikelihood (it is only an approximation, cf. paper)
more example1.completeloglikelihood 
-2.718888e+03

#To obtain the log topology prior taken at the maximum a posteriori
more example1.topologyprob  

#To obtain the final gene tree with the branch lengths
more  example1.tree


#To obtain the  sampled trees
#be careful it does not give the full list
more example1.treesampled


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#SECOND EXAMPLE : TWO  WGDs LOCATED IN THE SPECIES TREE
#we consider a species tree with 4 taxon (A, B, C, D)

#on this example, we consider the same WGD as before (i.e. the one located just before the speciation A|B)
#the second WGD is located on the branch just above (i.e. before the speciation AB|C)
#and not in the middle of that branch 


#We consider a probability of loss of 0.12 for the second  WGD (specified in the input file
#speciestreewith2WGD.stree)


#note that on this example, we consider as data set, the file dnawith2WGD/12/12.nt.align but  other dna alignments are located in
#the folder dnawith2WGD. All the alignments were generated using the same species tree with 2 WGD.


#Input files required to run SPIMAP on this example :

speciestreewith2WGD.stree : species tree
12.nt.align : sequence alignments (FASTA format)
ABCD.smap : gene to species map
ABCD.params : substitution rate parameter file

#The following command 

bin/spimap -s speciestreewith2WGD.stree -S ABCD.smap -a dnawith2WGD/12/12.nt.align  -o example2 -i 100 -D 0.02 -L 0.03  -g 2 -V 1 -p ABCD.params --log resultsexample2 --informationduploss -r --treeSampled -LR 0.95 

#will produce the following output 


Species tree from input file, including WGD nodes:
      /-- A 
   /+++     
/+++  \-- B 
|  |        
+  \--- C   
|           
\---- D     
            
            
            
(
  (
    (
      (
        (
          (
            (
              A:7.060000,
              B:7.060000
            ):2.500000
          )WGD_at:0.000000
        )WGD_before:2.500000,
        C:12.060000
      ):1.990000
    )WGD_at:0.000000
  )WGD_before:3.980000,
  D:18.030001
);


#we recall that crosses denote nodes
#we can see that two nodes have been added for each WGD


#then , the software describes the 2 WGD
#note that each WGD has its own number

WGD parameters, if any:
WGD event number0:
	loss probability:  0.100000
	percent distance:  0.500000
	total distance:    5.000000
	node number at the end of 'before' period: 9
	distance 'before': 2.500000
	node number at the end of 'at' period:     8
	node number at the end of 'after' period:  5
	distance 'after':  2.500000
WGD event number1:
	loss probability:  0.120000
	percent distance:  0.666667
	total distance:    5.970000
	node number at the end of 'before' period: 10
 	distance 'before': 3.980000
	node number at the end of 'at' period:     7
	node number at the end of 'after' period:  4
	distance 'after':  1.990000




the WGD species tree
0       D
1       A
2       B
3       C
4
        9       WGD_before
        3       C
5
        1       A
        2       B
6
        10      WGD_before
        0       D
7       WGD_at
        4
8       WGD_at
        5
9       WGD_before
        8       WGD_at
10      WGD_before
        7       WGD_at


the WGD species tree graphically:
(
  (
    (
      (
        (
          (
            (
              A:7.060000,
              B:7.060000
            ):2.500000
          )WGD_at:0.000000
        )WGD_before:2.500000,
        C:12.060000
      ):1.990000
    )WGD_at:0.000000
  )WGD_before:3.980000,
  D:18.030001
);




      /-- A 
   /+++     
/+++  \-- B 
|  |        
+  \--- C   
|           
\---- D     
            


        

Reduced species tree:
(
  (
    (
      A:7.060000,
      B:7.060000
    ):5.000000,
    C:12.060000
  ):5.970000,
  D:18.030001
);
    /-- A 
  /-+     
/-+ \-- B 
| |       
+ \--- C  
|         
\---- D   
          

#From the sequence alignments, we get the  'Neighbor-joining' tree        


   /- B_26 
   /+       
   |\- B_25 
  /+        
  ||/- B_13 
 /+\+       
 || \- A_12 
/+|         
||\- B_16   
||          
|\- D_39    
|           
+  /- B_37  
| /+        
| |\- A_36  
|/+         
|||/- B_34  
\+\+        
 | \- A_33  
 |          
 \- C_38    

#at the end, it prints the species tree and the final gene tree  

Correct gene tree from -c file:
now printing species tree
      /-- A 
   /+++     
/+++  \-- B 
|  |        
+  \--- C   
|           
\---- D     
            

0	D
1	A
2	B
3	C
4	n4
	9	WGD_before
	3	C
5	n7
	1	A
	2	B
6	n1
	10	WGD_before
	0	D
7	WGD_at
	4	n4
8	WGD_at
	5	n7
9	WGD_before
	8	WGD_at
10	WGD_before
	7	WGD_at


now printing final gene tree
  

/-- D_39       
|              
|    /- B_13   
|   /+         
|  /+\- A_12   
+  ||          
| /+\-- B_16   
| ||           
| ||/-- B_26   
| |\+          
| | \- B_25    
\-+            
  |  /-- B_37  
  | /+         
  | |\-- A_36  
  |/+          
  |||/- B_34   
  \+\+         
   | \- A_33   
   |           
   \----- C_38 

0	A_12
1	B_13
2	B_16
3	B_25
4	B_26
5	A_33
6	B_34
7	A_36
8	B_37
9	C_38
10	D_39
11	n5
	1	B_13
	0	A_12
12	n6
	4	B_26
	3	B_25
13	n10
	6	B_34
	5	A_33
14	n3
	15	n4
	12	n6
15	n4
	11	n5
	2	B_16
16	n9
	8	B_37
	7	A_36
17	n2
	14	n3
	19	n7
18	n8
	16	n9
	13	n10
19	n7
	18	n8
	9	C_38
20	n1
	10	D_39
	17	n2

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#In the file example2.recon you will find the RECONCILIATION
#it  specifies which nodes are reconciled at the WGD

#As in the original version of SPIMAP :
#first column refers to the gene tree :  name of the node
#second column refers to the species tree : name of the node
#third column indicates the evolutionary event : 'gene', 'speciation', 'duplication', 'WGD'

more example2.recon 

A_12	A	gene
B_13	B	gene
B_16	B	gene
B_25	B	gene
B_26	B	gene
A_33	A	gene
B_34	B	gene
A_36	A	gene
B_37	B	gene
C_38	C	gene
D_39	D	gene
n5	n7	spec
n6	B	dup
n10	n7	spec
n3	WGD_at0	WGD
n4	n7	dup
n9	n7	spec
n2	WGD_at1	WGD
n8	WGD_at0	WGD
n7	n4	spec
n1	n1	spec



#we can see that the software finds three duplications at the WGD 
#indeed, the node n2 of the gene tree maps to the WGD 1 (i.e. the one before the speciation AB|C)
#and the nodes n3 and n8 map to the WGD 0 (i.e.  the one before the speciation A|B)


# the file example2.duplosslasttree gives the number of events 

more example2.duplosslasttree 
3,0,5,3

#a total of 3 losses, 0 loss at the WGD, a total of 5 duplications, 3 duplications at the WGD
#be careful we only consider 100 iterations on this example
# as a result, you will probably find a different result if you run it 
