processInput <-
function(tr, geomMean=NULL, dirac=NULL, useRootStateMLE=F, 
	equalBDrates=F, fixedRetentionRates=T, startingValue=c(0.01, 0.02)){
	 # tr is phylo4d object from read.simmap()
	
	isNotNullGeomMean=!is.null(geomMean)
	isNotNullDirac=!is.null(dirac)
	
	if( (isNotNullGeomMean + isNotNullDirac + useRootStateMLE) !=1 )
		stop("Use one of these three arguments: geomMean or dirac or useRootStateMLE")
			

	if (isNotNullDirac){

	 isDiracInteger=(dirac==floor(dirac))
	 if (!isDiracInteger){
		dirac<-floor(dirac)
		warning("WARNING, the dirac value has to be an integer. The dirac value has been rounded down"
		, immediate.=TRUE)
		}
	}


	if (isNotNullGeomMean){			
		if (geomMean<0) {		
		stop("WARNING, the mean of the prior geometric distribution has to be greater or equal to 0")
		}
	}

	phyloMat = as.data.frame(tr@edge)
	 # phyloMat is a phylo matrix with nNode rows and 6 columns: 
	 # Parent Child  Time Species RetenRate LossRate
	 
	phyloMat = cbind(phyloMat, tr@edge.length)
	colnames(phyloMat) = c("Parent", "Child", "Time")
	
	phyloMat = phyloMat[order(phyloMat$Child), ]
	 # order the phyloMat$Child column in an increasing order
	
	phyloMat = cbind(phyloMat, Species=tr@label)
	
	r = which(phyloMat$Species == "Root")
	 # r is root node
	 
	phyloMat$Time[r] = -1
	 # root has time -1
	
	y = tr@data
	 # y contains retention rates
	 
	y = as.numeric( as.character(y[,1]))
	retenRate = c(y[1:(r-1)], 0, y[r:length(y)])
	
	phyloMat = cbind(phyloMat, RetenRate=retenRate)
	phyloMat$LossRate = 1 - phyloMat$RetenRate
	
	nLeaf = r-1
	nNode = nrow(phyloMat)
	nWGD = sum(phyloMat$Time == 0)
	 # number of WGD
	
	wgdNode = phyloMat$Parent[which(phyloMat$Time==0)]
	 # wgdNode is a vector of nodes before WGD
	

	#check Retention rates
	RetentionRatesNotPositive= ( sum(phyloMat[which(phyloMat$Time==0),5]>=0) != nWGD )
	RetentionRatesNotSmallerThanOne= ( sum(phyloMat[which(phyloMat$Time==0),5]<=1) != nWGD )

	if ( RetentionRatesNotPositive || RetentionRatesNotSmallerThanOne) {
		stop("ERROR. Retention Rates must take values in [0,1]")
		}

	para = NULL
	lower = upper = NULL
	 # lower and upper bounds for parameter vector para
	
	if(fixedRetentionRates){
		if(equalBDrates){
			para=c(log(startingValue[1]))
			lower = c(-Inf)
			upper = c(Inf)		
		} else { # birthRate != deathRate			
			para=c(log(startingValue[1]),log(startingValue[2]))
			lower = c(-Inf, -Inf)
			upper = c(Inf, Inf)
		}
		
	} else { # need to estimate retention rate
		if(equalBDrates){
			para=c(log(startingValue[1]), rep(0.5, nWGD))
			lower = c(-Inf, rep(0, nWGD))
			upper = c(Inf, rep(1, nWGD))
			
		} else { # birthRate != deathRate		
			para=c(log(startingValue[1]), log(startingValue[2]), rep(0.5, nWGD))
			lower = c(-Inf, -Inf, rep(0, nWGD))
			upper = c(Inf, Inf, rep(1, nWGD))
		}	
	}
	
	wgdTab = phyloMat[which(phyloMat$Time==0), c("Parent", "RetenRate", "LossRate")]
	names(wgdTab)[1] = "wgdNode"
	 # wgdTab is a table of 3 columns: 1st column is nodes before WGD
	 # 2nd and 3rd columns are q and p

	return( list(phyloMat=phyloMat, nLeaf=nLeaf, nNode=nNode, wgdTab = wgdTab,
	 para=para, lower=lower, upper=upper) )
}


