MLEGeneCount <-
function(tr, geneCountData, nPos=NULL, geomMean=NULL, dirac=NULL, useRootStateMLE=F, conditioning=c("oneOrMore", "twoOrMore", "oneInBothClades", "none"), equalBDrates=F, fixedRetentionRates=F, startingValue=c(0.01, 0.02)){
	
	 # tr has simmap format, i.e. phylo4d objects from read.simmap()
	 # species names on geneCountData should match species names (leaves) on the tree


	#check if data are integers
	if (isTRUE(all.equal(geneCountData, round(geneCountData)))) {
		geneCountData<-round(geneCountData)
	} else {
	stop("ERROR the data are not integer")
	}

	#check species
	if (dim(geneCountData)[2]!=length(tipLabels(tr))) {	
		stop("ERROR the number of species in the tree does not match the number of species in the data file")
	} else if (sum(names(geneCountData)%in% tipLabels(tr)) != length(tipLabels(tr))) {
		stop("ERROR the column names do not match the species name")
	}

	#check nPos	
	if(is.null(nPos)){
	# initializing the possible number of genes at each internal node of the phylogeny.
	  nPos = max(max(geneCountData)*3 +1, 101) 
		}		

	if ((nPos!=floor(nPos)) || nPos<0){
	stop("ERROR, the value of the parameter nPos must be a positive integer")
	}	

	if (nPos<(max(geneCountData)+1)|nPos<0) {
	stop("ERROR, the value of the parameter nPos is too small. It should be at least three times 
	the largest value observed in present-day species + 1. ")
	} else { 
		if (nPos<(max(geneCountData)*3+1)){
 		warning("WARNING, the value of the parameter nPos should be larger.  It should be at least three times 
	the largest value observed in present-day species + 1. "
		, immediate.=TRUE)
		}
	}

	 
	input = processInput(tr, geomMean, dirac, useRootStateMLE, equalBDrates, fixedRetentionRates, startingValue)
	 # processInput = function(tr, geomMean=NULL, dirac=NULL, useRootStateMLE=F, 
	 #  equalBDrates=F, fixedRetentionRates=T){
		
	para = input$para
	 # initial values for parameter
	lower = input$lower
	upper = input$upper
	
	# logLikGeneCount = function (para, input, geneCountData, nPos=101, geomMean=NULL, dirac=NULL, 
	#  useRootStateMLE=F, nCondData=NULL, fixedRetentionRates=T, equalBDrates=F) {}
	
	conditioning=match.arg(conditioning)

	if (conditioning=="twoOrMore") {	
	geneNumberInEachFamily<-rowSums(geneCountData, dims = 1)
	familiesNotAppropriate=which(geneNumberInEachFamily==1)

		if (length(familiesNotAppropriate)>0){	
		print("The following families are responsible for the ERROR")
			print(familiesNotAppropriate)	
		stop("ERROR about the conditioning, we can not use the type twoOrMore
		     since at least one family has only 1 gene copy")
		}
	} else if (conditioning=="oneInBothClades") {
		.checkClades(input$phyloMat, geneCountData, input$nLeaf)
	}

	result = optim(para, logLikGeneCount, input=input, 
	  geneCountData=geneCountData, nPos=nPos, geomMean=geomMean, dirac=dirac, useRootStateMLE=useRootStateMLE, conditioning=conditioning, fixedRetentionRates= fixedRetentionRates, equalBDrates= equalBDrates, method="L-BFGS-B", lower=lower, upper=upper)
		
	para = result$par
	loglik=-result$value
	
	wgdTab = input$wgdTab

	if(equalBDrates){
		lambda = exp(para[1])
		
		if(!fixedRetentionRates){
			wgdTab$RetenRate = para[-1]
			wgdTab$LossRate = 1 - wgdTab$RetenRate
		}	
				
	return(list(birthrate=lambda, deathrate="same as birth rate", loglikelihood=loglik, 
	  WGDtable=wgdTab, phyloMat=input$phyloMat, call=match.call(),convergence=result$convergence))
	
	} else { # not equal birth and deathrate		
		lambda = exp(para[1])
		mu = exp(para[2])
		
		if(!fixedRetentionRates){
			wgdTab$RetenRate = para[-c(1,2)]
			wgdTab$LossRate = 1 - wgdTab$RetenRate
		}
		
		return(list(birthrate=lambda, deathrate=mu, loglikelihood=loglik, 
	  		WGDtable=wgdTab, phyloMat=input$phyloMat[,1:4], call=match.call(),convergence=result$convergence))
	}
}
