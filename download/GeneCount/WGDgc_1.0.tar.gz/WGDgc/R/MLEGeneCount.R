MLEGeneCount <-
function(tr, geneCountData, mMax=NULL, geomMean=NULL, dirac=NULL, useRootStateMLE=FALSE, conditioning=c("oneOrMore", "twoOrMore", "oneInBothClades", "none"), equalBDrates=FALSE, fixedRetentionRates=FALSE, startingBDrates=c(0.01, 0.02),startingQ=NULL){
	
	 # tr has simmap format, i.e. phylo4d objects from read.simmap()
	 # species names on geneCountData should match species names (leaves) on the tree


	#check if data are integers
	if (isTRUE(all.equal(geneCountData, round(geneCountData)))) {
	 geneCountData<-round(geneCountData)
	} else {
	 stop("data are not of integer type")
	}

	#check species
	if (dim(geneCountData)[2]!=length(tipLabels(tr))) {	
	 stop("the number of species in the tree does not match the number of species in the data file")
	} else if (sum(names(geneCountData)%in% tipLabels(tr)) != length(tipLabels(tr))) {
	 stop("the column names do not match the species names")
	}

	#check mMax	
	if(is.null(mMax)){
          # initialize maximum # of surviving gene lineages
          mMax = max(apply(geneCountData,1,sum))
          # initializing the possible number of genes at each internal node of the phylogeny.
	  # nPos = max(max(geneCountData)*3 +1, 101)
	}		

	if ((mMax!=floor(mMax)) || mMax<=0){
	 stop("mMax must be a positive integer. Was ",mMax)
	}
        if (mMax< max(apply(geneCountData,1,sum))) {
          warning("the value of the parameter mMax should be larger to avoid approximations.", immediate.=TRUE)
	}

#	if (nPos<(max(geneCountData)+1)|nPos<0) {
#         stop("nPos is too small. It should be at least three times 
#	the largest value observed in present-day species + 1. ")
#	} else { 
#	 if (nPos<(max(geneCountData)*3+1)){
# 	 warning("the value of the parameter nPos should be larger.  It should be at least three times 
#	the largest value observed in present-day species + 1. ", immediate.=TRUE)
#	 }
#	}

        # checking options for prior at the root
        isNotNullGeomMean=!is.null(geomMean)
	isNotNullDirac=!is.null(dirac)
	if( (isNotNullGeomMean + isNotNullDirac + useRootStateMLE) !=1 )
          stop("Use exactly one of these three arguments: geomMean or dirac or useRootStateMLE")
	if (isNotNullDirac){
          isDiracInteger=(dirac==floor(dirac))
          if (!isDiracInteger){
            dirac<-floor(dirac)
            warning("the dirac value has to be an integer. It has been rounded down",immediate.=TRUE)
          }
          if (dirac<1){ stop("the dirac value needs to be positive.")}
	}
	if (isNotNullGeomMean){
          if (geomMean<1) {
            stop("the mean of the prior geometric distribution has to be greater or equal to 1")
          }
	}

	input = processInput(tr, equalBDrates, fixedRetentionRates, startingBDrates, startingQ)		
			
	nWGD=sum(input$phyloMat$Time == 0)
	if ((nWGD==0) & (!fixedRetentionRates)) {		
		fixedRetentionRates=TRUE
		warning("The tree has no WGD events, setting fixedRetentionRates to TRUE"
		, immediate.=TRUE)
		}
	#important when the species tree has no WGD
	
		
	para = input$para   # initial values for parameter
	lower = input$lower
	upper = input$upper
        if (!is.null(geomMean)){ geomProb=1/geomMean } else {geomProb=NULL} # processInput checked geomMean>=1.
		
	conditioning=match.arg(conditioning)
	if (conditioning=="twoOrMore") {	
	 geneNumberInEachFamily<-rowSums(geneCountData, dims = 1)
	 familiesNotAppropriate=which(geneNumberInEachFamily==1)

	 if (length(familiesNotAppropriate)>0){	
	  print("The following families are responsible for the error:\n  ")
	  print(familiesNotAppropriate)	
	  stop("conditioning: we cannot use the type twoOrMore
 since at least one family has only 1 gene copy")
	 }
	} else if (conditioning=="oneInBothClades") {
	 .checkClades(input$phyloMat, geneCountData, input$nLeaf)
	}

	result = optim(para, getLikGeneCount, input=input, geneCountData=geneCountData,
          mMax=mMax, geomProb=geomProb, dirac=dirac, useRootStateMLE=useRootStateMLE,
          conditioning=conditioning, fixedRetentionRates=fixedRetentionRates,
          equalBDrates=equalBDrates, method="L-BFGS-B", lower=lower, upper=upper)
		
	para = result$par
	loglik=-result$value
	
	wgdTab = input$wgdTab

	if(equalBDrates){
	 lambda = exp(para[1])
		
	 if(!fixedRetentionRates){
	  wgdTab$RetenRate = para[-1]
	  wgdTab$LossRate = 1 - wgdTab$RetenRate
	 }	
				
	 return(list(birthrate=lambda, deathrate="same as birth rate", loglikelihood=loglik, WGDtable=wgdTab, 
	  phyloMat=input$phyloMat, call=match.call(),convergence=result$convergence,mMax=mMax))
	
	} else { # not equal birth and deathrate		
	 lambda = exp(para[1])
	 mu = exp(para[2])
		
	 if(!fixedRetentionRates){
	  wgdTab$RetenRate = para[-c(1,2)]
	  wgdTab$LossRate = 1 - wgdTab$RetenRate
	 }
		
	 return(list(birthrate=lambda, deathrate=mu, loglikelihood=loglik, WGDtable=wgdTab, 
	  phyloMat=input$phyloMat[,1:4], call=match.call(),convergence=result$convergence,mMax=mMax))
	}
}
