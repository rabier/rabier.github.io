### Code regarding Tables 1 and 2  of the manuscript (2 QTLs or 100 QTLs)
 
### This code will fill a Table, called summaryTable
### each column gives an estimated accuracy according to a given method
### each row is one simulated data set
## finally, all results will be in a generated file called MyTableResults

###################### this code
### EmpiricalAccuracy : empirical Accuracy
#### TheoreticalAccuracy : rhocheck(beta)
####TheoreticalAccuracyTRNBased : rhohat(beta)
### TheoreticalAccuracyLASSO : rhocheck(betaLasso)
#### TheoreticalAccuracyLASSOTRN : rhohat(betaLasso)
#### TheoreticalAccuracyAdaptLASSO : rhocheck(betaAdaptiveLasso)
#### TheoreticalAccuracyAdaptLASSOTRN : rhohat(betaAdaptiveLasso)
#### TheoreticalAccuracyGroupLASSO : rhocheck(betaGroupLasso)
#### TheoreticalAccuracyGroupLASSOTRN : rhohat(betaGroupLasso)


library(hypred)
library(rrBLUP)
library(glmnet)

library(gglasso)
library(parcor)

### To be replaced by the location of your current directory
currentDirectory<-"/Users/Charley/Desktop/CodeScandinavian/ForOurUsers"
setwd(currentDirectory)
 
#source("getAccuracyRegeneratedTest.R")
source("functionsForAccuracy.R") 
#source("functionsForCompressedAccuracy.R")


### nbSNPS is the number of SNPS
nbSNPS<-100


### chroLength is the length of the chromosome
chroLength<-1

#we consider 2 QTLs at 3 cM and 80 cM
nbQTLs<-2 
QTLlocations<-c(0.03,0.80)
QTLeffects<-rep(0,nbQTLs)
QTLeffects[1]=1
QTLeffects[2]=-2

  
#other setting 
#nbQTLs<-100
##QTLlocations<-seq(0.01, 1, by = 0.01)
#QTLeffects<-rep(0.15,100)

## VarEnv is the environmental variance 
VarEnv<-1


### n is the number of Training individuals that are not full sibs
n<-500

### nbFullSibs is the number of FullSibs considered in the Training set (at least >=2)
nbFullSibs<-2 

### nbTRN is the number of Training individuals
nbTRN<-n+nbFullSibs


## nbTest is the number of Test individuals
nbTest<-100

##nbgeneration is the number of generations the population is evolving
nbgeneration<-50

### heritability refers to the heritability in case you want that
## your tuning parameter relies on heritability
heritability<-0.4

### REML , set to TRUE in case you want that your tuning parameter 
## relies on REML ( and not on heritability)
REML=TRUE

### if you want to use heritability based, REML has to be set to FALSE

### we work in perfect LD, so do not remove the QTL from the genomes
REMOVEQTL=FALSE

set.seed(288)

### nbSim is the number of simulations
nbSim<-100

summaryTable = data.frame(IDsim=1:nbSim, TheoreticalAccuracy=rep(0,nbSim), TheoreticalAccuracyTRNBased=rep(0,nbSim), EmpiricalAccuracy=rep(0,nbSim), 
TheoreticalAccuracyLASSO=rep(0,nbSim), TheoreticalAccuracyLASSOTRN=rep(0,nbSim), TheoreticalAccuracyAdaptLASSO=rep(0,nbSim), TheoreticalAccuracyAdaptLASSOTRN=rep(0,nbSim),
TheoreticalAccuracyGroupLASSO=rep(0,nbSim), TheoreticalAccuracyGroupLASSOTRN=rep(0,nbSim))

## 1 chromosome of length chroLength and nbSNPS SNPs
genomeDef <- hypredGenome(1, chroLength, nbSNPS)

###create a genetic map with markers at fixed location
step<-chroLength/nbSNPS
change_map <- seq(step,chroLength,step)
genomeDefFixedMap <- hypredNewMap(genomeDef,change_map)

###find the QTL index which corresponds to QTL locations
QTLindex<-QTLlocations/step
### QTL has to be on markers, they will be defined explicitely with hypredNewQTL

genomeDefFixedMapWithQTL <- hypredNewQTL(genomeDefFixedMap,
new.id.add = round(QTLindex),
new.id.dom = NULL, ## default
new.eff.add = QTLeffects,
new.eff.dom = NULL ## default
)


## produce two haploid founder line genomes
founder <- hypredFounder(genomeDefFixedMapWithQTL,1)
### these 2 lines are completely genetically different


## count the number of loci
nloci<-genomeDefFixedMapWithQTL@num.snp.chr + genomeDefFixedMapWithQTL@num.add.qtl.chr
genomesOvertime<-array(0,dim=c(nbgeneration,n,nloci))
##genomesOvertime[g,i,j] denotes the genome of individu i at locus j at generation g
#### generate genomes of the n individuals according to Wright Fisher
## Be careful, at the first generation , it is a population of n individuals who are descendents of the 2 founders
genomesOvertime<-WrightFisherPopulation(n,nbgeneration,nloci,founder,genomeDefFixedMapWithQTL)

## generate full sibs

genomeFullSibs<-array(0,dim=c(nbFullSibs,nloci))
#genomeFullSibs[i,j] will denote genome of sib i at loci j

#Choose 2 parents randomly among the n individuals
indparentsFullSibs<-sample(seq(1,n), 2, replace = FALSE)

genomeFullSibs<-generateFullSibs(nbFullSibs,nloci,genomesOvertime[nbgeneration,indparentsFullSibs[1],], genomesOvertime[nbgeneration,indparentsFullSibs[2],],genomeDefFixedMapWithQTL)


for (idSample in 1:nbSim) {


####### Generate Test individuals, ie phenotypes, and genome matrix,

#### genomesTest is the genome of Test individuals
genomesTest<-array(0,dim=c(nbTest,nloci))

### Test individuals are nbTest extra individual from the random mating, so go back to generation nbgeneration-1
genomesTest<-generateTestIndividuals(genomesOvertime[nbgeneration-1,,],n,nbTest,nloci,genomeDefFixedMapWithQTL)

#################################
### generate phenotypes

QTLeffectsMatrix<-matrix(genomeDefFixedMapWithQTL@add.and.dom.eff$add,ncol=1)
Y<-rep(0,n)
Y[1:n]<-generatePhenotypes(genomesOvertime[nbgeneration, , genomeDefFixedMapWithQTL@pos.add.qtl$ID],QTLeffectsMatrix,VarEnv)
 
#generate phenotypes of full Sibs
YFullSibs<-rep(0,nbFullSibs)
YFullSibs<-generatePhenotypes(genomeFullSibs[,genomeDefFixedMapWithQTL@pos.add.qtl$ID],QTLeffectsMatrix,VarEnv)

YTRN<-rep(0,nbTRN)
YTRN<-c(Y,YFullSibs)
## YTRN contains phenotypes of the TRN
## we center the phenotypes of TRN
YTRNCentered<-YTRN-mean(YTRN)


#generate phenotypes of Tests
YTest<-rep(0,nbTest)
YTest<-generatePhenotypes(genomesTest[,genomeDefFixedMapWithQTL@pos.add.qtl$ID],QTLeffectsMatrix,VarEnv)
## we center the phenotypes of Test
YTestCentered<-YTest -  mean(YTest)

################################################
allGenomes<-array(0,dim=c(n+nbFullSibs+nbTest,nloci))
### Fill all genomes, by respectively n indiv, Full Sibs, and Tests
#recall that we focus only on last generation
allGenomes<-mergeGenomes(genomesOvertime[nbgeneration, ,],genomeFullSibs,genomesTest)

#######################################
## check if the user asked to remove the QTLs from the SNP matrix

if  (REMOVEQTL==TRUE) {
### Remove QTLs
allGenomesPreFiltered<-allGenomes[ , -genomeDefFixedMapWithQTL@pos.add.qtl$ID]
} else {
###Do not remove QTLs
### for the scandinavian paper, it is this case, since we are under perfect LD !
allGenomesPreFiltered<-allGenomes
}


##########################################

### Remove SNP not unique
### i.e. identical SNPs along the chromosome are filtered out, keeping only the first occurence of that
##### SNP on the chromosome
indSNPDup<-which(duplicated(t(allGenomesPreFiltered)))
allGenomesWithoutDup<-removeSNPNotUnique(indSNPDup, allGenomesPreFiltered)

### keep only SNPS with polymorphisms

sumCol<-apply(allGenomesWithoutDup[,],2,sum)
markNotPoly<-which(sumCol==dim(allGenomesWithoutDup)[1] | sumCol==0)
allGenomesWithoutDupPoly<-keepSNPSPolymorphic(markNotPoly, allGenomesWithoutDup)
NbRemainingMarkers<-dim(allGenomesWithoutDupPoly)[2]

##########Center TRN genomes and Test genomes

GenomeTRNCentered<-array(0,dim=c(nbTRN,dim(allGenomesWithoutDupPoly)[2]))
#genomeTRNCentered[i,j] denotes the genome of indiv i of TRN at locus j , but centered
## Recall that in TRN we consider that we have the n indiv and Full Sibs
GenomeTRNCentered<-calcCenteredGenomes(allGenomesWithoutDupPoly[1:nbTRN,])

indFirstTest<-n+nbFullSibs+1
indLastTest<-n+nbFullSibs+nbTest
GenomeTestCentered<-calcCenteredGenomes(allGenomesWithoutDupPoly[indFirstTest:indLastTest,])
#genomeTestCentered[i,j] denotes the genome of indiv i of Test at locus j , but centered

#####################Compute the Lambda, ie the tuning parameter either by REML or heritability based

data <- data.frame(phenoTrain=YTRNCentered, gid=seq(1,nbTRN))
rownames(GenomeTRNCentered)<-seq(1,nbTRN)
myK<- GenomeTRNCentered %*% t(GenomeTRNCentered)
#myK is my Kinship matrix

if (REML==TRUE){
##### we want to USE REML 
### use kin.blup to obtain variance components
u<-kin.blup(data=data, geno="gid", pheno="phenoTrain", K=myK)
### lambda REML
lambda<-u$Ve/u$Vg
} else {
### The tuning parameter is heritability based
lambda <- ( ( 1 - heritability) / (heritability) ) * dim(allGenomesWithoutDupPoly)[2] * mean( diag(var(allGenomesWithoutDupPoly[1:nbTRN,1:dim(allGenomesWithoutDupPoly)[2]]) ) )
}


################################### Evaluation of the prediction model on Test individuals


##### compute Ridge regression
matrixT <- solve(myK + lambda*diag(nbTRN))


######################################### Empirical Bias, Empirical Accuracy and Empirical Quadratic Error
 
### Prediction for Test individual
TestPrediction<-GenomeTestCentered[,] %*% t(GenomeTRNCentered[,])  %*% matrixT %*% YTRNCentered

##Empirical Bias
EmpiricalBias= mean(YTestCentered - TestPrediction)

#Empirical Accuracy
EmpiricalAccuracy<-cor(YTestCentered , TestPrediction)

### Empirical Quadratic Error
EmpiricalQuadraticError= mean( (YTestCentered- TestPrediction)^2 ) 



#################### Perfect LD proxies #############################################

########## Focus on  LASSO estimator

MyLassoCV<-cv.glmnet(GenomeTRNCentered, YTRNCentered, standardize =FALSE, intercept=FALSE, alpha=1)

MyLassoCoeff<-coef(MyLassoCV, MyLassoCV$lambda.1se)

########## Focus on Adaptive LASSO 

MyAdapt<-adalasso(GenomeTRNCentered,YTRNCentered,k=10)

MyAdaptLassoCoeff<-MyAdapt$coefficients.adalasso

#### Focus on Group LASSO 

NbGroupsForGroupLASSO<-floor(NbRemainingMarkers/10)

MyGroups= rep(1:NbGroupsForGroupLASSO,each=10)

if  ( (NbRemainingMarkers%%10) != 0 ) {

MyGroupToAdd<-rep((NbGroupsForGroupLASSO+1), NbRemainingMarkers%%10)

MyGroups<-c(MyGroups,MyGroupToAdd)
}

cvGroupLASSO <- cv.gglasso(GenomeTRNCentered, YTRNCentered, MyGroups, loss="ls",
pred.loss="L2", lambda.factor=0.05, nfolds=5)

MyGroupLassoCoeff<-coef(cvGroupLASSO,s=cvGroupLASSO$lambda.1se)


###################################### Theoretical Bias, Accuracy  

RR<-GenomeTestCentered[,] %*% t(GenomeTRNCentered[,]) %*% matrixT[,]
DesignTerm<-sum(RR^2)/nbTest

## Linkage disequilibrium corrected for relatedness , between SNPS and QTLs, for the Training
genomeAtQTLTRNCentered<-calcCenteredGenomes(allGenomes[1:nbTRN, genomeDefFixedMapWithQTL@pos.add.qtl$ID])
LDCorrectedWithQTLTRN<-t(GenomeTRNCentered[,]) %*% matrixT[,]  %*% genomeAtQTLTRNCentered

### Center the genome at QTL of Test 
genomeAtQTLTestCentered<-calcCenteredGenomes(genomesTest[,genomeDefFixedMapWithQTL@pos.add.qtl$ID])
##note that genomeTest is the genome of Test before filtering

#### Compute Theoretical Bias
TheoreticalBias<-mean(GenomeTestCentered %*% LDCorrectedWithQTLTRN %*% QTLeffectsMatrix - genomeAtQTLTestCentered %*% QTLeffectsMatrix)


###Compute rhocheck(beta), i.e. Theoretical Accuracy
TheoreticalAccuracy<-computeTheoreticalAccuracy(GenomeTestCentered, genomeAtQTLTestCentered, LDCorrectedWithQTLTRN, QTLeffectsMatrix, DesignTerm, VarEnv)

###Compute rhohat(beta)
TheoreticalAccuracyTRNBased<-computeTheoreticalAccuracy(GenomeTRNCentered, genomeAtQTLTRNCentered, LDCorrectedWithQTLTRN, QTLeffectsMatrix, DesignTerm, VarEnv)


#################### Perfect LD proxies #############################################
 

LDCorrectedWithQTLLASSOTRN<-t(GenomeTRNCentered[,]) %*% matrixT[,]  %*% GenomeTRNCentered[,]


### compute rhocheck(betaLasso)
TheoreticalAccuracyLASSO<-computeTheoreticalAccuracy(GenomeTestCentered, GenomeTestCentered, LDCorrectedWithQTLLASSOTRN, MyLassoCoeff[2:(NbRemainingMarkers+1)], DesignTerm, VarEnv)

### compute rhohat(betaLasso)
TheoreticalAccuracyLASSOTRN<-computeTheoreticalAccuracy(GenomeTRNCentered, GenomeTRNCentered, LDCorrectedWithQTLLASSOTRN, MyLassoCoeff[2:(NbRemainingMarkers+1)], DesignTerm, VarEnv)

### compute rhocheck(AdaptLasso)
TheoreticalAccuracyAdaptLASSO<-computeTheoreticalAccuracy(GenomeTestCentered, GenomeTestCentered, LDCorrectedWithQTLLASSOTRN, MyAdaptLassoCoeff, DesignTerm, VarEnv)

### compute rhohat(AdaptLasso)
TheoreticalAccuracyAdaptLASSOTRN<-computeTheoreticalAccuracy(GenomeTRNCentered, GenomeTRNCentered, LDCorrectedWithQTLLASSOTRN, MyAdaptLassoCoeff, DesignTerm, VarEnv)

### compute rhocheck(GroupLasso)
TheoreticalAccuracyGroupLASSO<-computeTheoreticalAccuracy(GenomeTestCentered, GenomeTestCentered, LDCorrectedWithQTLLASSOTRN, as.vector(MyGroupLassoCoeff[2:(NbRemainingMarkers+1)]), DesignTerm, VarEnv)

### compute rhohat(GroupLasso)
TheoreticalAccuracyGroupLASSOTRN<-computeTheoreticalAccuracy(GenomeTRNCentered, GenomeTRNCentered, LDCorrectedWithQTLLASSOTRN, as.vector(MyGroupLassoCoeff[2:(NbRemainingMarkers+1)]), DesignTerm, VarEnv)


######### Write Table in File

summaryTable$EmpiricalAccuracy[idSample] <- EmpiricalAccuracy

summaryTable$TheoreticalAccuracy[idSample] <- TheoreticalAccuracy

summaryTable$TheoreticalAccuracyTRNBased[idSample] <- TheoreticalAccuracyTRNBased

summaryTable$TheoreticalAccuracyLASSO[idSample] <- TheoreticalAccuracyLASSO

summaryTable$TheoreticalAccuracyLASSOTRN[idSample] <- TheoreticalAccuracyLASSOTRN

summaryTable$TheoreticalAccuracyAdaptLASSO[idSample] <- TheoreticalAccuracyAdaptLASSO

summaryTable$TheoreticalAccuracyAdaptLASSOTRN[idSample] <- TheoreticalAccuracyAdaptLASSOTRN

summaryTable$TheoreticalAccuracyGroupLASSO[idSample] <- TheoreticalAccuracyGroupLASSO

summaryTable$TheoreticalAccuracyGroupLASSOTRN[idSample] <- TheoreticalAccuracyGroupLASSOTRN

write.table(summaryTable, file="MyTableResults", quote=F, sep="\t", row.names=F, col.names=T)

}



