### Code regarding Tables 4 and 5 of the manuscript (n=500 or 800)

### This code will fill a Table, called summaryTable
### each column gives an estimated accuracy according to a given method
### each row is one simulated data set
## finally, all results will be in a generated file called MyTableResults

#####################
#EmpiricalAccuracy : empirical Accuracy
#TheoreticalAccuracy: rhocheck(beta)
#TheoreticalAccuracyTRN : rhohat(beta)
#MyCompressedAccuracy : rhotildehat(beta)
#Criteria1
#Criteria2
#MyRatio
#MyRatioLogit 
#EmpiricalAccuracyReduced : Cor(Ytildenew,Ynew)
######################

library(hypred)
library(rrBLUP)
library(glmnet)
library(gglasso)
library(parcor)

### To be replaced by the location of your current directory
currentDirectory<-"/Users/Charley/Desktop/CodeScandinavian/ForOurUsers"
setwd(currentDirectory)
  
source("functionsForAccuracy.R")  
source("getSmartAxes.R")


### nbSNPS is the number of SNPS
nbSNPS<-4000

### chroLength is the length of the chromosome
chroLength<-4

#we consider 100 QTLs located on the first Morgan, with effects +0.15
nbQTLs<-100
QTLlocations<-seq(0.01,1,0.01)
QTLeffects<-rep(0.15,100)

### heritability refers to the heritability in case you want that
## your tuning parameter relies on heritability
heritability<-0.4

### n is the number of Training individuals that are not full sibs
n<-800

### nbFullSibs is the number of FullSibs considered in the Training set (at least >=2)
nbFullSibs<-2 

### nbTRN is the number of Training individuals
nbTRN<-n+nbFullSibs

## nbTest is the number of Test individuals
nbTest<-100

### nbgeneration number of generations the population is evolving
nbgeneration<-50

### REML , set to TRUE in case you want that your tuning parameter 
## relies on REML ( and not on heritability)
REML=TRUE
### if you want to use heritability based, REML has to be set to FALSE

REMOVEQTL=FALSE

## VarEnv is the environmental variance 
VarEnv<-9
set.seed(422)

### nbSim is the number of simulations
nbSim<-100

summaryTable = data.frame(IDsim=1:nbSim, TheoreticalAccuracy=rep(0,nbSim), EmpiricalAccuracy=rep(0,nbSim),
TheoreticalAccuracyTRN=rep(0,nbSim), MyCompressedAccuracy=rep(0,nbSim), Criteria1=rep(0,nbSim), Criteria2=rep(0,nbSim),
MyRatio=rep(0,nbSim), MyRatioLogit=rep(0,nbSim), EmpiricalAccuracyReduced=rep(0,nbSim))


## 1 chromosome of length chroLength and nbSNPS SNPs
genomeDef <- hypredGenome(1, chroLength, nbSNPS)

###create a genetic map with markers at fixed location
step<-chroLength/nbSNPS
change_map <- seq(step,chroLength,step)
genomeDefFixedMap <- hypredNewMap(genomeDef,change_map)

###find the QTL index which corresponds to QTL locations
QTLindex<-QTLlocations/step
### QTL has to be on markers, they will be defined explicitely with hypredNewQTL

genomeDefFixedMapWithQTL <- hypredNewQTL(genomeDefFixedMap,
new.id.add = round(QTLindex),
new.id.dom = NULL, ## default
new.eff.add = QTLeffects,
new.eff.dom = NULL ## default
)


## produce two haploid founder line genomes
founder <- hypredFounder(genomeDefFixedMapWithQTL,1)
### these 2 lines are completely genetically different

## count the number of loci
nloci<-genomeDefFixedMapWithQTL@num.snp.chr + genomeDefFixedMapWithQTL@num.add.qtl.chr
genomesOvertime<-array(0,dim=c(nbgeneration,n,nloci))
##genomesOvertime[g,i,j] denotes the genome of individu i at locus j at generation g
#### generate genomes of the n individuals according to Wright Fisher
## Be careful, at the first generation , it a population of n individuals who are descendents of the 2 founders
genomesOvertime<-WrightFisherPopulation(n,nbgeneration,nloci,founder,genomeDefFixedMapWithQTL)

## generate full sibs

genomeFullSibs<-array(0,dim=c(nbFullSibs,nloci))
#genomeFullSibs[i,j] will denote genome of sib i at loci j

#Choose 2 parents randomly among the n individuals
indparentsFullSibs<-sample(seq(1,n), 2, replace = FALSE)

genomeFullSibs<-generateFullSibs(nbFullSibs,nloci,genomesOvertime[nbgeneration,indparentsFullSibs[1],], genomesOvertime[nbgeneration,indparentsFullSibs[2],],genomeDefFixedMapWithQTL)


for (idSample in 1:nbSim) {


####### Generate Test individuals, ie phenotypes, and genome matrix,


#### genomesTest is the genome of Test individuals
genomesTest<-array(0,dim=c(nbTest,nloci))

### Test individuals are nbTest extra individual from the random mating, so go back to generation nbgeneration-1
genomesTest<-generateTestIndividuals(genomesOvertime[nbgeneration-1,,],n,nbTest,nloci,genomeDefFixedMapWithQTL)

#################################
### generate phenotypes
QTLeffectsMatrix<-matrix(genomeDefFixedMapWithQTL@add.and.dom.eff$add,ncol=1)
Y<-rep(0,n)
Y[1:n]<-generatePhenotypes(genomesOvertime[nbgeneration, , genomeDefFixedMapWithQTL@pos.add.qtl$ID],QTLeffectsMatrix,VarEnv)
 
#generate phenotypes of full Sibs
YFullSibs<-rep(0,nbFullSibs)
YFullSibs<-generatePhenotypes(genomeFullSibs[,genomeDefFixedMapWithQTL@pos.add.qtl$ID],QTLeffectsMatrix,VarEnv)

YTRN<-rep(0,nbTRN)
YTRN<-c(Y,YFullSibs)
## YTRN contains phenotypes of the TRN
## we center the phenotypes of TRN
YTRNCentered<-YTRN-mean(YTRN)

#generate phenotypes of Tests
YTest<-rep(0,nbTest)
YTest<-generatePhenotypes(genomesTest[,genomeDefFixedMapWithQTL@pos.add.qtl$ID],QTLeffectsMatrix,VarEnv)
## we center the phenotypes of Test
YTestCentered<-YTest -  mean(YTest)


################################################
allGenomes<-array(0,dim=c(n+nbFullSibs+nbTest,nloci))
### Fill all genomes, by respectively n indiv, Full Sibs, and Tests
#recall that we focus only on last generation
allGenomes<-mergeGenomes(genomesOvertime[nbgeneration, ,],genomeFullSibs,genomesTest)

#######################################
## check if the user asked to remove the QTLs from the SNP matrix

if  (REMOVEQTL==TRUE) {
### Remove QTLs
allGenomesPreFiltered<-allGenomes[ , -genomeDefFixedMapWithQTL@pos.add.qtl$ID]
} else {
###Do not remove QTLs
### it is the case for the scandinavian paper
allGenomesPreFiltered<-allGenomes
}

##########################################

### Remove SNP not unique
### i.e. identical SNPs along the chromosome are filtered out, keeping only the first occurence of that
##### SNP on the chromosome
indSNPDup<-which(duplicated(t(allGenomesPreFiltered)))
allGenomesWithoutDup<-removeSNPNotUnique(indSNPDup, allGenomesPreFiltered)

### keep only SNPS with polymorphisms
sumCol<-apply(allGenomesWithoutDup[,],2,sum)
markNotPoly<-which(sumCol==dim(allGenomesWithoutDup)[1] | sumCol==0)
allGenomesWithoutDupPoly<-keepSNPSPolymorphic(markNotPoly, allGenomesWithoutDup)
NbRemainingMarkers<-dim(allGenomesWithoutDupPoly)[2]


##########Center TRN genomes and Test genomes

GenomeTRNCentered<-array(0,dim=c(nbTRN,dim(allGenomesWithoutDupPoly)[2]))
#genomeTRNCentered[i,j] denotes the genome of indiv i of TRN at locus j , but centered
## Recall that in TRN we consider that we have the n indiv and Full Sibs
GenomeTRNCentered<-calcCenteredGenomes(allGenomesWithoutDupPoly[1:nbTRN,])

indFirstTest<-n+nbFullSibs+1
indLastTest<-n+nbFullSibs+nbTest
GenomeTestCentered<-calcCenteredGenomes(allGenomesWithoutDupPoly[indFirstTest:indLastTest,])
#genomeTestCentered[i,j] denotes the genome of indiv i of Test at locus j , but centered

#####################Compute the Lambda, ie the tuning parameter either by REML or heritability based

data <- data.frame(phenoTrain=YTRNCentered, gid=seq(1,nbTRN))
rownames(GenomeTRNCentered)<-seq(1,nbTRN)
myK<- GenomeTRNCentered %*% t(GenomeTRNCentered)
#myK is my Kinship matrix

if (REML==TRUE){
##### we want to USE REML 
### use kin.blup to obtain variance components
u<-kin.blup(data=data, geno="gid", pheno="phenoTrain", K=myK)
### lambda REML
lambda<-u$Ve/u$Vg
} else {
### The tuning parameter is heritability based
lambda <- ( ( 1 - heritability) / (heritability) ) * dim(allGenomesWithoutDupPoly)[2] * mean( diag(var(allGenomesWithoutDupPoly[1:nbTRN,1:dim(allGenomesWithoutDupPoly)[2]]) ) )
}


################################### Evaluation of the prediction model on Test individuals
##### compute Ridge regression
matrixT <- solve(myK + lambda*diag(nbTRN))

######################################### Empirical Bias, Empirical Accuracy and Empirical Quadratic Error
 
### Prediction for Test individual
TestPrediction<-GenomeTestCentered[,] %*% t(GenomeTRNCentered[,])  %*% matrixT %*% YTRNCentered

##Empirical Bias
EmpiricalBias= mean(YTestCentered - TestPrediction)

#Empirical Accuracy
EmpiricalAccuracy<-cor(YTestCentered , TestPrediction)

summaryTable$EmpiricalAccuracy[idSample] <- EmpiricalAccuracy

###################################### Theoretical Accuracy  

RR<-GenomeTestCentered[,] %*% t(GenomeTRNCentered[,]) %*% matrixT[,]
DesignTerm<-sum(RR^2)/nbTest

RRTRN<-GenomeTRNCentered[,] %*% t(GenomeTRNCentered[,]) %*% matrixT[,]
DesignTermTRN<-sum(RRTRN^2)/nbTRN

## Linkage disequilibrium corrected for relatedness , between SNPS and QTLs, for the Training
genomeAtQTLTRNCentered<-calcCenteredGenomes(allGenomes[1:nbTRN, genomeDefFixedMapWithQTL@pos.add.qtl$ID])
LDCorrectedWithQTLTRN<-t(GenomeTRNCentered[,]) %*% matrixT[,]  %*% genomeAtQTLTRNCentered

### Center the genome at QTL of Test 
genomeAtQTLTestCentered<-calcCenteredGenomes(genomesTest[,genomeDefFixedMapWithQTL@pos.add.qtl$ID])
##note that genomeTest is the genome of Test before filtering

###Compute rhocheck(beta), that we call Theoretical Accuracy
TheoreticalAccuracy<-computeTheoreticalAccuracy(GenomeTestCentered, genomeAtQTLTestCentered, LDCorrectedWithQTLTRN, QTLeffectsMatrix, DesignTerm, VarEnv)

###Compute rhohat(beta), that we call TheoreticalAccuracyTRN
TheoreticalAccuracyTRNAndFriends<-computeTheoreticalAccuracyWithDetails(GenomeTRNCentered, genomeAtQTLTRNCentered, LDCorrectedWithQTLTRN, QTLeffectsMatrix, DesignTermTRN, VarEnv)

TheoreticalAccuracyTRN<-TheoreticalAccuracyTRNAndFriends[[1]]

summaryTable$TheoreticalAccuracy[idSample]<-TheoreticalAccuracy

summaryTable$TheoreticalAccuracyTRN[idSample]<-TheoreticalAccuracyTRN
 
#####  Let us compute the SVD now for couputing the modifed predictor

svdMatTrainings<-svd(GenomeTRNCentered)

MatDiag <- Diagonal(x=svdMatTrainings$d)

svdMatTest<-svd(GenomeTestCentered)

MatDiagTest <- Diagonal(x=svdMatTest$d)

RankGenomeTestCentered <- rankMatrix(GenomeTestCentered,method = "qrLINPACK", tol=1e-20)

RankGenomeTRNCentered <- rankMatrix(GenomeTRNCentered,method = "qrLINPACK", tol=1e-20)

#######################
## Look for QTL locations within the Design Matrix (because of the filtering) 
  	
indQTL<-rep(0,nbQTLs)

for (myQTL in 1:nbQTLs) { 

indQTLTRN<-which(apply(GenomeTRNCentered, 2, function(x) identical(as.vector(x[1:dim(GenomeTRNCentered)[1]]), genomeAtQTLTRNCentered[1:dim(GenomeTRNCentered)[1],myQTL])))

## be careful, there may be several indices for the same QTL in the TRN matrix
## since the filtering for identical SNPs was performed on the matix containing TRN+Test
 if (length(indQTLTRN)> 1) {

indQTLTest<- which(apply(GenomeTestCentered, 2, function(x) identical(as.vector(x[1:dim(GenomeTestCentered)[1]]), genomeAtQTLTestCentered[1:dim(GenomeTestCentered)[1],myQTL])))
indQTL[myQTL]<-indQTLTest[1]


}else{

indQTL[myQTL]<-indQTLTRN
    
}

  }

################################################

## ThetaTilde will be my sparse vector  
ThetaTilde<-rep(0,NbRemainingMarkers)
ThetaTilde[indQTL]<-QTLeffects
 
VarGenetTest<-var(genomeAtQTLTestCentered %*% QTLeffectsMatrix)


###############Let us compute rhotildehat(beta), that we call MyCompressedAccuracy

 ### Let us choose axes smartly 
MyP1<-c(0.7,0.8,0.9, 0.925, 0.95, 0.975, 0.99)

MyCompressedAccuracy<-0
IDAxes<-0

for (compteur in 1:length(MyP1)){

IDAxesNew=getSmartAxes(RankGenomeTRNCentered[1],ThetaTilde,svdMatTrainings,MyP1[compteur])

InterestingTerms<-ComputeCompressedAccuracySmartAxes(IDAxesNew,nbTRN,ThetaTilde,svdMatTrainings,GenomeTRNCentered,matrixT,lambda,genomeAtQTLTRNCentered,QTLeffectsMatrix)

VarGenetTRN<-var(genomeAtQTLTRNCentered %*% QTLeffectsMatrix)

DenomCompressed<-sqrt( VarGenetTRN + VarEnv) *  sqrt(VarEnv*InterestingTerms[[2]] + InterestingTerms[[3]])

MyCompressedAccuracyNew<-InterestingTerms[[1]]/DenomCompressed


	if ( MyCompressedAccuracyNew > MyCompressedAccuracy ) {

		IDAxes<-IDAxesNew
		 
		MyCompressedAccuracy<-MyCompressedAccuracyNew

		summaryTable$MyCompressedAccuracy[idSample]<-MyCompressedAccuracy

		MyCriteria<-computeCriteria(TheoreticalAccuracyTRNAndFriends,InterestingTerms)

		summaryTable$Criteria1[idSample]<-MyCriteria[[1]]

		summaryTable$Criteria2[idSample]<-MyCriteria[[2]]

		MyRatio<-InterestingTerms[[1]]/TheoreticalAccuracyTRNAndFriends[[2]]
  
		MyRatioLogit<-MyRatio/(1-MyRatio)

		summaryTable$MyRatio[idSample]<-MyRatio

		summaryTable$MyRatioLogit[idSample]<-MyRatioLogit }

}


############## Compute Cor(Ytildenew,Ynew), that we
### call Empirical accuracy Reduced

TestPredictionReduced<-GenomeTestCentered[,] %*% t(GenomeTRNCentered[,])  %*% matrixT %*% 
+ svdMatTrainings$u[, IDAxes] %*% t(svdMatTrainings$u[, IDAxes] )%*% YTRNCentered

EmpiricalAccuracyReduced<-cor(YTestCentered , TestPredictionReduced)

summaryTable$EmpiricalAccuracyReduced[idSample]<-EmpiricalAccuracyReduced

  
######################################################
 
######### Write Table in File
write.table(summaryTable, file="MyTableResults", quote=F, sep="\t", row.names=F, col.names=T)
###write.table(summaryTable, file="Ici", quote=F, sep="\t", row.names=F, col.names=T)

}



