

####### function for choosing the best axes   

getSmartAxes<-function(RankforTRN,ThetaTilde,svdMatTrainings,p1){

WeightedL2projections<-rep(0,RankforTRN)

for (i in 1:RankforTRN){

WeightedMyVecti<-( svdMatTrainings$d[i]^2 ) / (sqrt(svdMatTrainings$d[i]^2 + lambda)) *   svdMatTrainings$v[,i]%*%t(svdMatTrainings$v[,i]) %*% ThetaTilde

WeightedL2projections[i]<-sum(WeightedMyVecti^2)

}

IndWeightedL2projectionsOrdered<-order(WeightedL2projections,decreasing=TRUE)


### look for axes that explain p1 of the weighted projection 
ratioWeightedL2=0
i<-0
while(ratioWeightedL2 < p1) {
i<-i+1
ratioWeightedL2<-sum(WeightedL2projections[IndWeightedL2projectionsOrdered[1:i]])/sum(WeightedL2projections)

}

IndWeightedL2LastOrdered<-i

return(IndWeightedL2projectionsOrdered[1:IndWeightedL2LastOrdered])

}


##################################################################
## function for Computing compressed accuracy with smart axes
 
ComputeCompressedAccuracySmartAxes<-function(IDAxes,nbTRN,ThetaTilde,svdMatTrainings,GenomeTRNCentered,matrixT,lambda,genomeAtQTLTRNCentered,QTLeffectsMatrix){
## It computes a compressed accuracy as a function of the rank of the two matrices

## ID Axes are my  smart axes

NbAxes<-length(IDAxes)

################### Compute Var Term

LDCorrectedWithQTLTRNSmart<-t(GenomeTRNCentered[,]) %*% matrixT[,]  %*% svdMatTrainings$u[,IDAxes] %*% t(svdMatTrainings$u[,IDAxes]) %*% genomeAtQTLTRNCentered

VarCompressTerm<-t(QTLeffectsMatrix)%*%t(LDCorrectedWithQTLTRNSmart) %*% var(GenomeTRNCentered) %*% LDCorrectedWithQTLTRNSmart %*% QTLeffectsMatrix

### design Term

NumTermDesignCompress<-( svdMatTrainings$d[IDAxes]^4 ) 

DenomTermDesignCompress<-(svdMatTrainings$d[IDAxes]^2 + lambda)^2 

DesignCompressTerm<-sum(NumTermDesignCompress/DenomTermDesignCompress)/nbTRN


######################### Focus on numerator 

NumCompressFirstVersion<- t(ThetaTilde) %*% var(GenomeTRNCentered) %*% t(GenomeTRNCentered[,])  %*% matrixT %*% svdMatTrainings$u[,IDAxes] %*% t(svdMatTrainings$u[,IDAxes]) %*% GenomeTRNCentered[,] %*%
ThetaTilde

NumCompressTerm<- NumCompressFirstVersion*(nbTRN-1)/nbTRN


############################################

MyInterestingTerms = list(NumCompressTerm, DesignCompressTerm, VarCompressTerm)

return(MyInterestingTerms)

}


##################################################################################

computeTheoreticalAccuracyWithDetails<-function(GenomeTestCentered, genomeAtQTLTestCentered, LDCorrectedWithQTLTRN, QTLeffectsMatrix, DesignTerm, VarEnv){
### compute the Theoretical Accuracy
### same function as computeTheoreticalAccuracy, but returning also the different terms

#### input
### GenomeTestCentered : Genome of Test individual that have been centered, matrix of size nbTest x NbRemainingMarkers
### genomeAtQTLTestCentered :  Genome of Test individual at the QTL  (centered), matrix of size nbTest x nbQTLs
### QTLeffectsMatrix : matrix of size nbQTLs x 1, containing the QTLs effects
### LDCorrectedWithQTLTRN : matrix of size NbRemainingMarkers X nbQTLs, containing the corrected LD for the TRN individuals
### DesignTerm :  design term, it is equal to NewMe/nbTRN


T1<-GenomeTestCentered %*% LDCorrectedWithQTLTRN %*% QTLeffectsMatrix 
T2<-genomeAtQTLTestCentered %*% QTLeffectsMatrix
NumTheoreticalAccuracy<-mean(T1*T2)

###Denominator

##Compute Variance of GenomeTestCentered %*% LDCorrectedWithQTLTRN %*% QTLeffectsMatrix
VarTerm<-t(QTLeffectsMatrix)%*%t(LDCorrectedWithQTLTRN) %*% var(GenomeTestCentered) %*% LDCorrectedWithQTLTRN %*% QTLeffectsMatrix
## Compute Genetic Variance in Test
VarGenetTest<-var(genomeAtQTLTestCentered %*% QTLeffectsMatrix)
DenomTheoreticalAccuracy<-sqrt( VarGenetTest + VarEnv) *  sqrt(VarEnv*DesignTerm + VarTerm)
TheoreticalAccuracy<-NumTheoreticalAccuracy/DenomTheoreticalAccuracy
return(list(TheoreticalAccuracy,NumTheoreticalAccuracy, DesignTerm, VarTerm))

}


###############################################################

computeCriteria<-function(TheoreticalAccuracyTRNAndFriends,InterestingTerms){

## function for computing terms to figure out if the improving criteria is fulfilled

### To begin with, first criteria

A2<-TheoreticalAccuracyTRNAndFriends[[3]]
A3<-TheoreticalAccuracyTRNAndFriends[[4]]

A2Smart <- InterestingTerms[[2]]
A3Smart <- InterestingTerms[[3]]

SumA2A3 <-  A2 + A3
SumA2A3Smart <-  A2Smart + A3Smart

#NumCrit1 <- SumA2A3Smart - sqrt( SumA2A3Smart * (2*SumA2A3Smart + SumA2A3))
NumCrit1 <- SumA2A3Smart - sqrt( SumA2A3Smart * SumA2A3)
DenomCrit1 <- SumA2A3 - SumA2A3Smart

Crit1 <- NumCrit1/DenomCrit1

### second criteria

#NumCrit2 <- SumA2A3Smart + sqrt( SumA2A3Smart * (2*SumA2A3Smart + SumA2A3))
NumCrit2 <- SumA2A3Smart + sqrt( SumA2A3Smart * SumA2A3)
DenomCrit2 <- SumA2A3 - SumA2A3Smart

Crit2 <- NumCrit2/DenomCrit2

return(list(Crit1,Crit2))

}












